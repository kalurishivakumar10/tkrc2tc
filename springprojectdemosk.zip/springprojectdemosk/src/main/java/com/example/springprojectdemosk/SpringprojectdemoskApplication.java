package com.example.springprojectdemosk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringprojectdemoskApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringprojectdemoskApplication.class, args);
	}

}
