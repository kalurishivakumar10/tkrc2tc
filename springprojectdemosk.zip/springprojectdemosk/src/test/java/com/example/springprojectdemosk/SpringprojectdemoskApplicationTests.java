package com.example.springprojectdemosk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringprojectdemoskApplicationTests {

	@Test
	void contextLoads() {
	}

}
